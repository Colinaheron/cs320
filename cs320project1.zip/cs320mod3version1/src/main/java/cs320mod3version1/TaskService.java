package cs320mod3version1;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private Map<String, Task> tasks;

    public TaskService() {
        this.tasks = new HashMap<>();
    }

    public void addTask(String taskID, String name, String description) {
        if (tasks.containsKey(taskID)) {
            throw new IllegalArgumentException("Task with ID " + taskID + " already exists.");
        }

        Task task = new Task(taskID, name, description);
        tasks.put(taskID, task);
    }

    public void deleteTask(String taskID) {
        tasks.remove(taskID);
    }

    public void updateTaskField(String taskID, String field, String newValue) {
        Task task = tasks.get(taskID);
        if (task == null) {
            throw new IllegalArgumentException("Task with ID " + taskID + " not found.");
        }

        switch (field) {
            case "name":
                task = new Task(taskID, newValue, task.getDescription());
                break;
            case "description":
                task = new Task(taskID, task.getName(), newValue);
                break;
            default:
                throw new IllegalArgumentException("Invalid field for update: " + field);
        }

        tasks.put(taskID, task);
    }

    public Task getTask(String taskID) {
        return tasks.get(taskID);
    }
}

