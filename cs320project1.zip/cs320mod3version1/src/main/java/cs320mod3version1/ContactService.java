package cs320mod3version1;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts;

    public ContactService() {
        this.contacts = new HashMap<>();
    }

    public void addContact(String contactID, String firstName, String lastName, String phone, String address) {
    	 if (contacts.containsKey(contactID)) {
             throw new IllegalArgumentException("Contact with ID " + contactID + " already exists.");
         }
        Contact contact = new Contact(contactID, firstName, lastName, phone, address);
        contacts.put(contactID, contact);
    }

    public void deleteContact(String contactID) {
        contacts.remove(contactID);
    }

    public void updateContact(String contactID, String newFirstName, String newLastName, String newPhone, String newAddress) {
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact with ID " + contactID + " not found.");
        }

        if (newFirstName != null) {
            contact = new Contact(contactID, newFirstName, contact.getLastName(), contact.getPhone(), contact.getAddress());
        }
        if (newLastName != null) {
            contact = new Contact(contactID, contact.getFirstName(), newLastName, contact.getPhone(), contact.getAddress());
        }
        if (newPhone != null) {
            contact = new Contact(contactID, contact.getFirstName(), contact.getLastName(), newPhone, contact.getAddress());
        }
        if (newAddress != null) {
            contact = new Contact(contactID, contact.getFirstName(), contact.getLastName(), contact.getPhone(), newAddress);
        }

        contacts.put(contactID, contact);
    }
    
    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }
}

