package cs320mod3version1;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private Map<String, Appointment> appointments;

    public AppointmentService() {
        this.appointments = new HashMap<>();
    }

    public void addAppointment(String appointmentID, Date appointmentDate, String description) {
        if (appointments.containsKey(appointmentID)) {
            throw new IllegalArgumentException("Appointment with ID " + appointmentID + " already exists.");
        }

        Appointment appointment = new Appointment(appointmentID, appointmentDate, description);
        appointments.put(appointmentID, appointment);
    }

    public void deleteAppointment(String appointmentID) {
        appointments.remove(appointmentID);
    }

    public Appointment getAppointment(String appointmentID) {
        return appointments.get(appointmentID);
    }
}