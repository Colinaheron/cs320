package cs320mod3version1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Test;

import org.junit.Before;

public class ContactServiceTest {
	private ContactService contactService;
	
	@Before
    public void setUp() {
        // Initialize a new ContactService before each test
        contactService = new ContactService();
    }

    @Test
    public void testAddContactWithUniqueID() {
        contactService.addContact("12345", "John", "Doe", "1234567890", "123 Main St");
        Contact contact = contactService.getContact("12345");
        assertNotNull(contact);
    }

    @Test
    public void testDeleteContact() {
        contactService.addContact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.deleteContact("12345");
        assertNull(contactService.getContact("12345"));
    }

    @Test
    public void testUpdateFirstName() {
        contactService.addContact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.updateContact("12345", "Jane", "Doe", "1234567890", "123 Main St");
        Contact contact = contactService.getContact("12345");
        assertEquals("Jane", contact.getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        contactService.addContact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.updateContact("12345", "John", "Smith", "1234567890", "123 Main St");
        Contact contact = contactService.getContact("12345");
        assertEquals("Smith", contact.getLastName());
    }

    @Test
    public void testUpdatePhone() {
        contactService.addContact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.updateContact("12345", "John", "Doe", "9876543210", "123 Main St");
        Contact contact = contactService.getContact("12345");
        assertEquals("9876543210", contact.getPhone());
    }

    @Test
    public void testUpdateAddress() {
        contactService.addContact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.updateContact("12345", "John", "Doe", "1234567890", "456 Elm St");
        Contact contact = contactService.getContact("12345");
        assertEquals("456 Elm St", contact.getAddress());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddContactWithDuplicateID() {
        contactService.addContact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact("12345", "Jane", "Smith", "9876543210", "456 Elm St");
    }
    

}
