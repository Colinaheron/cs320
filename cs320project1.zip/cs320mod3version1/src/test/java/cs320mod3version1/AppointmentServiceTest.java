package cs320mod3version1;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.Date;

public class AppointmentServiceTest {
    private AppointmentService appointmentService;

    @Before
    public void setUp() {
        // Initialize a new AppointmentService before each test
        appointmentService = new AppointmentService();
    }

    @Test
    public void testAddAppointmentWithUniqueID() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // One day in the future
        appointmentService.addAppointment("123", futureDate, "AppointmentDescription");
        Appointment appointment = appointmentService.getAppointment("123");
        assertNotNull(appointment);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddAppointmentWithDuplicateID() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // One day in the future
        appointmentService.addAppointment("123", futureDate, "AppointmentDescription");
        appointmentService.addAppointment("123", futureDate, "NewAppointmentDescription");
    }

    @Test
    public void testDeleteAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // One day in the future
        appointmentService.addAppointment("123", futureDate, "AppointmentDescription");
        appointmentService.deleteAppointment("123");
        assertNull(appointmentService.getAppointment("123"));
    }

    @Test
    public void testGetAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // One day in the future
        appointmentService.addAppointment("123", futureDate, "AppointmentDescription");
        Appointment appointment = appointmentService.getAppointment("123");
        assertNotNull(appointment);
        assertEquals("123", appointment.getAppointmentID());
    }
}
