package cs320mod3version1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class ContactTest {

	@Test
	public void testContact() {
		Contact contact = new Contact("1", "colin", "aheron", "7043404657", "234 S Laurel ave, Charlotte NC");
		assertTrue(contact.getContactID().equals("1"));
		assertTrue(contact.getFirstName().equals("colin"));
		assertTrue(contact.getLastName().equals("aheron"));
		assertTrue(contact.getPhone().equals("7043404657"));
		assertTrue(contact.getAddress().equals("234 S Laurel ave, Charlotte NC"));
	}
	
	@Test 
	public void testContactIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678911", "colin", "aheron", "7043404657", "234 S Laurel ave, Charlotte NC");
		}); }
	
	@Test 
	public void testContactIDIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "colin", "aheron", "7043404657", "234 S Laurel ave, Charlotte NC");
		}); }
	
	@Test 
	public void testContactFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "colin678911", "aheron", "7043404657", "234 S Laurel ave, Charlotte NC");
		}); }
	
	@Test 
	public void testContactFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", null, "aheron", "7043404657", "234 S Laurel ave, Charlotte NC");
		}); }
	
	@Test 
	public void testContactLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "colin", "aheron78911", "7043404657", "234 S Laurel ave, Charlotte NC");
		}); }
	
	@Test 
	public void testContactLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "colin", null, "7043404657", "234 S Laurel ave, Charlotte NC");
		}); }

	@Test 
	public void testContactPhoneTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "colin", "aheron", "70434046571", "234 S Laurel ave, Charlotte NC");
		}); }
	
	@Test 
	public void testContactPhoneTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "colin", "aheron", "704340465", "234 S Laurel ave, Charlotte NC");
		}); }
	
	@Test 
	public void testContactPhoneIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "colin", "aheron", null, "234 S Laurel ave, Charlotte NC");
		}); }
	
	@Test 
	public void testContactAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "colin", "aheron", "7043404657", "234 S Laurel ave, Charlotte NCC");
		}); }
	
	@Test 
	public void testContactAddressIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "colin", "aheron", "7043404657", null);
		}); }
}
