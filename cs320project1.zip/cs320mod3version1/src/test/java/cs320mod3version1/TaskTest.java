package cs320mod3version1;

import static org.junit.Assert.*;

import org.junit.Test;

public class TaskTest {

	    @Test
	    public void testValidTaskCreation() {
	        Task task = new Task("123", "TaskName", "TaskDescription");
	        assertNotNull(task);
	    }

	    @Test(expected = IllegalArgumentException.class)
	    public void testInvalidTaskIDNull() {
	        new Task(null, "TaskName", "TaskDescription");
	    }

	    @Test(expected = IllegalArgumentException.class)
	    public void testInvalidTaskIDTooLong() {
	        new Task("VeryLongTaskID", "TaskName", "TaskDescription");
	    }

	    @Test(expected = IllegalArgumentException.class)
	    public void testInvalidNameNull() {
	        new Task("123", null, "TaskDescription");
	    }

	    @Test(expected = IllegalArgumentException.class)
	    public void testInvalidNameTooLong() {
	        new Task("123", "VeryLongTaskNameThatExceedsTwentyCharacters", "TaskDescription");
	    }

	    @Test(expected = IllegalArgumentException.class)
	    public void testInvalidDescriptionNull() {
	        new Task("123", "TaskName", null);
	    }

	    @Test(expected = IllegalArgumentException.class)
	    public void testInvalidDescriptionTooLong() {
	        new Task("123", "TaskName", "VeryLongTaskDescriptionThatExceedsFiftyCharactersLimitForDescription");
	    }

	    @Test
	    public void testGetTaskID() {
	        Task task = new Task("123", "TaskName", "TaskDescription");
	        assertEquals("123", task.getTaskID());
	    }

	    @Test
	    public void testGetName() {
	        Task task = new Task("123", "TaskName", "TaskDescription");
	        assertEquals("TaskName", task.getName());
	    }

	    @Test
	    public void testGetDescription() {
	        Task task = new Task("123", "TaskName", "TaskDescription");
	        assertEquals("TaskDescription", task.getDescription());
	    }
	}
