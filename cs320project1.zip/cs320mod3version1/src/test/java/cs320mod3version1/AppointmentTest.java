package cs320mod3version1;

import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // One day in the future
        Appointment appointment = new Appointment("123", futureDate, "AppointmentDescription");
        assertNotNull(appointment);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidAppointmentIDNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // One day in the future
        new Appointment(null, futureDate, "AppointmentDescription");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidAppointmentIDTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // One day in the future
        new Appointment("VeryLongAppointmentID", futureDate, "AppointmentDescription");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidAppointmentDateNull() {
        new Appointment("123", null, "AppointmentDescription");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidAppointmentDateInPast() {
        Date pastDate = new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000); // One day in the past
        new Appointment("123", pastDate, "AppointmentDescription");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidDescriptionNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // One day in the future
        new Appointment("123", futureDate, null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidDescriptionTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // One day in the future
        new Appointment("123", futureDate, "VeryLongAppointmentDescriptionThatExceedsFiftyCharacters");
    }

    @Test
    public void testGetAppointmentID() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // One day in the future
        Appointment appointment = new Appointment("123", futureDate, "AppointmentDescription");
        assertEquals("123", appointment.getAppointmentID());
    }

    @Test
    public void testGetAppointmentDate() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // One day in the future
        Appointment appointment = new Appointment("123", futureDate, "AppointmentDescription");
        assertEquals(futureDate, appointment.getAppointmentDate());
    }

    @Test
    public void testGetDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // One day in the future
        Appointment appointment = new Appointment("123", futureDate, "AppointmentDescription");
        assertEquals("AppointmentDescription", appointment.getDescription());
    }
}
