package cs320mod3version1;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class TaskServiceTest {
    private TaskService taskService;

    @Before
    public void setUp() {
        // Initialize a new TaskService before each test
        taskService = new TaskService();
    }

    @Test
    public void testAddTaskWithUniqueID() {
        taskService.addTask("123", "TaskName", "TaskDescription");
        Task task = taskService.getTask("123");
        assertNotNull(task);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddTaskWithDuplicateID() {
        taskService.addTask("123", "TaskName", "TaskDescription");
        taskService.addTask("123", "NewTaskName", "NewTaskDescription");
    }

    @Test
    public void testDeleteTask() {
        taskService.addTask("123", "TaskName", "TaskDescription");
        taskService.deleteTask("123");
        assertNull(taskService.getTask("123"));
    }

    @Test
    public void testUpdateName() {
        taskService.addTask("123", "TaskName", "TaskDescription");
        taskService.updateTaskField("123", "name", "NewTaskName");
        Task task = taskService.getTask("123");
        assertEquals("NewTaskName", task.getName());
    }

    @Test
    public void testUpdateDescription() {
        taskService.addTask("123", "TaskName", "TaskDescription");
        taskService.updateTaskField("123", "description", "NewTaskDescription");
        Task task = taskService.getTask("123");
        assertEquals("NewTaskDescription", task.getDescription());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpdateInvalidField() {
        taskService.addTask("123", "TaskName", "TaskDescription");
        taskService.updateTaskField("123", "invalidField", "NewValue");
    }
}
